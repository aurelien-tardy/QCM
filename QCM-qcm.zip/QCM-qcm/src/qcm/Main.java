package qcm;

import qcm.Vue.Vue_Principale;

/**
 *
 * @author aurélien
 */
public class Main {

    
    public static void main(String[] args) {
      Vue_Principale f = new Vue_Principale();
       
    }
    
}
