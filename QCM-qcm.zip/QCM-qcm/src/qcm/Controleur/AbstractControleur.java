/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qcm.Controleur;

import java.util.ArrayList;

/**
 *
 * @author aurélien
 */
public abstract class AbstractControleur {
    public abstract boolean control(ArrayList<String> list);
        
}
